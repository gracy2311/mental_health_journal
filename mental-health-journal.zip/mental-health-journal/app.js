// DOM Elements
const mainContent = document.getElementById('mainContent');
const newEntryBtn = document.getElementById('newEntryBtn');
const historyBtn = document.getElementById('historyBtn');
const settingsBtn = document.getElementById('settingsBtn');
const newEntryModal = document.getElementById('newEntryModal');
const closeModalBtn = document.getElementById('closeModalBtn');
const saveEntryBtn = document.getElementById('saveEntryBtn');
const entryDate = document.getElementById('entryDate');
const entryContent = document.getElementById('entryContent');
const moodIcons = document.querySelectorAll('.mood-icon');

// Global variables
let currentMood = '';
let entries = JSON.parse(localStorage.getItem('journalEntries')) || [];

// Event Listeners
newEntryBtn.addEventListener('click', showNewEntryModal);
historyBtn.addEventListener('click', showHistory);
settingsBtn.addEventListener('click', showSettings);
closeModalBtn.addEventListener('click', closeNewEntryModal);
saveEntryBtn.addEventListener('click', saveEntry);
moodIcons.forEach(icon => {
    icon.addEventListener('click', selectMood);
});

// Functions
function showNewEntryModal() {
    newEntryModal.style.display = 'block';
    entryDate.value = dayjs().format('YYYY-MM-DD');
    entryContent.value = '';
    currentMood = '';
    moodIcons.forEach(icon => icon.style.opacity = '0.5');
}

function closeNewEntryModal() {
    newEntryModal.style.display = 'none';
}

function selectMood(event) {
    currentMood = event.target.dataset.mood;
    moodIcons.forEach(icon => {
        icon.style.opacity = icon.dataset.mood === currentMood ? '1' : '0.5';
    });
}

function saveEntry() {
    const newEntry = {
        date: entryDate.value,
        content: entryContent.value,
        mood: currentMood
    };
    entries.push(newEntry);
    localStorage.setItem('journalEntries', JSON.stringify(entries));
    closeNewEntryModal();
    showHistory();
}

function showHistory() {
    mainContent.innerHTML = `
        <h2>Journal History</h2>
        <input type="text" id="searchInput" placeholder="Search entries...">
        <ul class="entry-list">
            ${entries.map(entry => `
                <li class="entry-item">
                    <span class="entry-date">${entry.date}</span>
                    <span class="entry-mood">${getMoodEmoji(entry.mood)}</span>
                    <p class="entry-content">${entry.content}</p>
                </li>
            `).join('')}
        </ul>
    `;
    document.getElementById('searchInput').addEventListener('input', searchEntries);
}

function searchEntries(event) {
    const searchTerm = event.target.value.toLowerCase();
    const filteredEntries = entries.filter(entry => 
        entry.content.toLowerCase().includes(searchTerm) ||
        entry.date.includes(searchTerm) ||
        entry.mood.toLowerCase().includes(searchTerm)
    );
    updateEntryList(filteredEntries);
}

function updateEntryList(filteredEntries) {
    const entryList = document.querySelector('.entry-list');
    entryList.innerHTML = filteredEntries.map(entry => `
        <li class="entry-item">
            <span class="entry-date">${entry.date}</span>
            <span class="entry-mood">${getMoodEmoji(entry.mood)}</span>
            <p class="entry-content">${entry.content}</p>
        </li>
    `).join('');
}

function getMoodEmoji(mood) {
    switch(mood) {
        case 'happy': return '😊';
        case 'neutral': return '😐';
        case 'sad': return '😔';
        default: return '';
    }
}

function showSettings() {
    mainContent.innerHTML = `
        <h2>Settings</h2>
        <div class="settings-option">
            <label for="darkModeToggle">Dark Mode</label>
            <label class="toggle-switch">
                <input type="checkbox" id="darkModeToggle">
                <span class="slider"></span>
            </label>
        </div>
        <div class="settings-option">
            <button id="resetDataBtn">Reset All Data</button>
        </div>
    `;
    document.getElementById('darkModeToggle').addEventListener('change', toggleDarkMode);
    document.getElementById('resetDataBtn').addEventListener('click', resetData);
}

function toggleDarkMode(event) {
    if (event.target.checked) {
        document.body.classList.add('dark-mode');
        localStorage.setItem('darkMode', 'enabled');
    } else {
        document.body.classList.remove('dark-mode');
        localStorage.setItem('darkMode', 'disabled');
    }
}

function resetData() {
    if (confirm('Are you sure you want to reset all data? This action cannot be undone.')) {
        localStorage.removeItem('journalEntries');
        entries = [];
        showHistory();
    }
}

// Initialize the app
function init() {
    if (localStorage.getItem('darkMode') === 'enabled') {
        document.body.classList.add('dark-mode');
        document.getElementById('darkModeToggle').checked = true;
    }
    showHistory();
}

init();

