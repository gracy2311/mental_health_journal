export const emotions = [
  { label: 'Happy', emoji: '😊', color: '#FFD700' },  // Gold
  { label: 'Sad', emoji: '😔', color: '#87CEEB' },    // Sky Blue
  { label: 'Angry', emoji: '😠', color: '#FF4500' },  // Red Orange
  { label: 'Excited', emoji: '😃', color: '#FF69B4' }, // Hot Pink
  { label: 'Calm', emoji: '😌', color: '#90EE90' },   // Light Green
  { label: 'Anxious', emoji: '😰', color: '#BA55D3' }, // Medium Orchid
  { label: 'Loved', emoji: '🥰', color: '#FF69B4' },  // Deep Pink
  { label: 'Stressed', emoji: '😫', color: '#8B4513' }, // Saddle Brown
  { label: 'Grateful', emoji: '🙏', color: '#DDA0DD' }, // Plum
  { label: 'Bored', emoji: '😒', color: '#A9A9A9' },   // Dark Gray
];

export function getEmotionColor(emotion: string): string {
  const found = emotions.find(e => e.label.toLowerCase() === emotion.toLowerCase());
  return found ? found.color : '#FFFFFF'; // Default to white if not found
}

