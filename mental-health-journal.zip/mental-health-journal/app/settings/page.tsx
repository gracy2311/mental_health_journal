'use client'

import { useState, useEffect } from 'react'
import { useTheme } from 'next-themes'
import { motion } from 'framer-motion'

export default function Settings() {
  const { theme, setTheme } = useTheme()
  const [isResetting, setIsResetting] = useState(false)
  const [reminderTime, setReminderTime] = useState('20:00')
  const [password, setPassword] = useState('')

  useEffect(() => {
    const storedReminderTime = localStorage.getItem('reminderTime')
    if (storedReminderTime) {
      setReminderTime(storedReminderTime)
    }
    const storedPassword = localStorage.getItem('journalPassword')
    if (storedPassword) {
      setPassword(storedPassword)
    }
  }, [])

  const handleResetData = () => {
    if (confirm('Are you sure you want to reset all data? This action cannot be undone.')) {
      setIsResetting(true)
      localStorage.removeItem('journalEntries')
      localStorage.removeItem('reminderTime')
      localStorage.removeItem('journalPassword')
      setTimeout(() => {
        setIsResetting(false)
        alert('All data has been reset.')
      }, 1000)
    }
  }

  const handleReminderTimeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setReminderTime(e.target.value)
    localStorage.setItem('reminderTime', e.target.value)
  }

  const handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPassword(e.target.value)
    localStorage.setItem('journalPassword', e.target.value)
  }

  const handleExportData = () => {
    const journalData = localStorage.getItem('journalEntries')
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(journalData || '[]')
    const downloadAnchorNode = document.createElement('a')
    downloadAnchorNode.setAttribute("href", dataStr)
    downloadAnchorNode.setAttribute("download", "journal_backup.json")
    document.body.appendChild(downloadAnchorNode)
    downloadAnchorNode.click()
    downloadAnchorNode.remove()
  }

  return (
    <div className="max-w-2xl mx-auto">
      <h1 className="text-3xl font-bold mb-6">Settings</h1>
      <div className="space-y-6">
        <div>
          <h2 className="text-xl font-semibold mb-2">Theme</h2>
          <select
            value={theme}
            onChange={(e) => setTheme(e.target.value)}
            className="w-full p-2 border rounded-md focus:ring-2 focus:ring-blue-500 dark:bg-gray-800 dark:border-gray-700"
          >
            <option value="system">System</option>
            <option value="light">Light</option>
            <option value="dark">Dark</option>
          </select>
        </div>
        <div>
          <h2 className="text-xl font-semibold mb-2">Daily Reminder</h2>
          <input
            type="time"
            value={reminderTime}
            onChange={handleReminderTimeChange}
            className="w-full p-2 border rounded-md focus:ring-2 focus:ring-blue-500 dark:bg-gray-800 dark:border-gray-700"
          />
        </div>
        <div>
          <h2 className="text-xl font-semibold mb-2">Password Protection</h2>
          <input
            type="password"
            value={password}
            onChange={handlePasswordChange}
            placeholder="Set a password"
            className="w-full p-2 border rounded-md focus:ring-2 focus:ring-blue-500 dark:bg-gray-800 dark:border-gray-700"
          />
        </div>
        <div>
          <h2 className="text-xl font-semibold mb-2">Data Management</h2>
          <motion.button
            onClick={handleExportData}
            className="w-full py-2 px-4 bg-green-600 text-white rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 mb-4"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Export Data
          </motion.button>
          <motion.button
            onClick={handleResetData}
            disabled={isResetting}
            className="w-full py-2 px-4 bg-red-600 text-white rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 disabled:opacity-50"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            {isResetting ? 'Resetting...' : 'Reset All Data'}
          </motion.button>
        </div>
      </div>
    </div>
  )
}

