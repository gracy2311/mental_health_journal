'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { Chart, registerables } from 'chart.js'
import { motion } from 'framer-motion'
import { emotions, getEmotionColor } from '../utils/emotions'
import { useEmotionTheme } from '../components/ThemeProvider'

Chart.register(...registerables)

interface JournalEntry {
  id: number
  date: string
  content: string
  emotion: string
  gratitude?: string
}

export default function History() {
  const [entries, setEntries] = useState<JournalEntry[]>([])
  const [searchTerm, setSearchTerm] = useState('')
  const { setEmotionColor } = useEmotionTheme()

  useEffect(() => {
    const storedEntries = JSON.parse(localStorage.getItem('journalEntries') || '[]')
    setEntries(storedEntries)

    // Create emotion analysis chart
    const emotionCounts = storedEntries.reduce((acc, entry) => {
      acc[entry.emotion] = (acc[entry.emotion] || 0) + 1
      return acc
    }, {})

    const ctx = document.getElementById('emotionChart') as HTMLCanvasElement
    new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: Object.keys(emotionCounts),
        datasets: [{
          data: Object.values(emotionCounts),
          backgroundColor: Object.keys(emotionCounts).map(emotion => getEmotionColor(emotion)),
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: 'top',
          },
          title: {
            display: true,
            text: 'Emotion Distribution'
          }
        }
      }
    })

    // Set the emotion color based on the most recent entry
    if (storedEntries.length > 0) {
      const mostRecentEmotion = storedEntries[storedEntries.length - 1].emotion
      setEmotionColor(getEmotionColor(mostRecentEmotion))
    }
  }, [setEmotionColor])

  const filteredEntries = entries.filter((entry) =>
    entry.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
    entry.emotion.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (entry.gratitude && entry.gratitude.toLowerCase().includes(searchTerm.toLowerCase()))
  )

  const exportToPDF = () => {
    const element = document.getElementById('journal-entries')
    if (element) {
      html2pdf()
        .from(element)
        .save('journal_entries.pdf')
    }
  }

  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-6 emotion-text">Journal History</h1>
      <input
        type="text"
        placeholder="Search entries..."
        className="w-full p-2 mb-4 border rounded-md focus:ring-2 focus:ring-blue-500 dark:bg-gray-800 dark:border-gray-700 emotion-border"
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
      />
      <div className="mb-8">
        <h2 className="text-2xl font-bold mb-4 emotion-text">Emotion Analysis</h2>
        <canvas id="emotionChart" width="400" height="200"></canvas>
      </div>
      <motion.button
        onClick={exportToPDF}
        className="mb-4 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 emotion-bg"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        Export to PDF
      </motion.button>
      <div id="journal-entries" className="space-y-4">
        {filteredEntries.map((entry) => (
          <motion.div
            key={entry.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            className="bg-white dark:bg-gray-800 p-4 rounded-md shadow"
          >
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm text-gray-500 dark:text-gray-400">
                {new Date(entry.date).toLocaleDateString()}
              </span>
              <span className="text-2xl">{emotions.find(e => e.label === entry.emotion)?.emoji}</span>
            </div>
            <p className="text-gray-700 dark:text-gray-300 mb-2">{entry.content}</p>
            {entry.gratitude && (
              <p className="text-sm text-gray-600 dark:text-gray-400 italic">
                Grateful for: {entry.gratitude}
              </p>
            )}
            <Link
              href={`/entry/${entry.id}`}
              className="text-blue-600 dark:text-blue-400 hover:underline mt-2 inline-block emotion-text"
            >
              View Details
            </Link>
          </motion.div>
        ))}
      </div>
    </div>
  )
}

