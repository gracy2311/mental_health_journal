'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { motion } from 'framer-motion'
import BreathingExercise from './components/BreathingExercise'
import { inspirationalQuotes } from './utils/quotes'
import { emotions, getEmotionColor } from './utils/emotions'
import { useEmotionTheme } from './components/ThemeProvider'

export default function Home() {
  const [content, setContent] = useState('')
  const [selectedEmotion, setSelectedEmotion] = useState('')
  const [gratitude, setGratitude] = useState('')
  const [quote, setQuote] = useState({ text: '', author: '' })
  const router = useRouter()
  const { setEmotionColor } = useEmotionTheme()

  useEffect(() => {
    const randomQuote = inspirationalQuotes[Math.floor(Math.random() * inspirationalQuotes.length)]
    setQuote(randomQuote)
  }, [])

  useEffect(() => {
    if (selectedEmotion) {
      const color = getEmotionColor(selectedEmotion)
      setEmotionColor(color)
    }
  }, [selectedEmotion, setEmotionColor])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const entry = {
      id: Date.now(),
      date: new Date().toISOString(),
      content,
      emotion: selectedEmotion,
      gratitude,
    }
    const entries = JSON.parse(localStorage.getItem('journalEntries') || '[]')
    localStorage.setItem('journalEntries', JSON.stringify([...entries, entry]))
    router.push('/history')
  }

  return (
    <div className="max-w-4xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg mb-8"
      >
        <h2 className="text-2xl font-bold mb-4 emotion-text">Daily Inspiration</h2>
        <p className="text-lg italic">"{quote.text}"</p>
        <p className="text-right mt-2">- {quote.author}</p>
      </motion.div>

      <h1 className="text-3xl font-bold mb-6 emotion-text">New Journal Entry</h1>
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="content" className="block mb-2 font-medium emotion-text">
            How are you feeling today?
          </label>
          <textarea
            id="content"
            rows={6}
            className="w-full p-2 border rounded-md focus:ring-2 focus:ring-blue-500 dark:bg-gray-800 dark:border-gray-700 emotion-border"
            value={content}
            onChange={(e) => setContent(e.target.value)}
            required
          ></textarea>
        </div>
        <div>
          <label className="block mb-2 font-medium emotion-text">Select your emotion:</label>
          <div className="flex flex-wrap gap-4">
            {emotions.map((emotion) => (
              <motion.button
                key={emotion.label}
                type="button"
                onClick={() => setSelectedEmotion(emotion.label)}
                className={`text-3xl p-2 rounded-full ${
                  selectedEmotion === emotion.label
                    ? 'ring-2 ring-offset-2'
                    : 'hover:bg-gray-100 dark:hover:bg-gray-800'
                }`}
                style={{ backgroundColor: emotion.color }}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
              >
                {emotion.emoji}
              </motion.button>
            ))}
          </div>
        </div>
        <div>
          <label htmlFor="gratitude" className="block mb-2 font-medium emotion-text">
            What are you grateful for today?
          </label>
          <input
            type="text"
            id="gratitude"
            className="w-full p-2 border rounded-md focus:ring-2 focus:ring-blue-500 dark:bg-gray-800 dark:border-gray-700 emotion-border"
            value={gratitude}
            onChange={(e) => setGratitude(e.target.value)}
          />
        </div>
        <motion.button
          type="submit"
          className="w-full py-2 px-4 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 emotion-bg"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          Save Entry
        </motion.button>
      </form>
      <div className="mt-8">
        <BreathingExercise />
      </div>
    </div>
  )
}

