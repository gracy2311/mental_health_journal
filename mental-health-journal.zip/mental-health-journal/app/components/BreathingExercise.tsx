'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'

export default function BreathingExercise() {
  const [isBreathing, setIsBreathing] = useState(false)
  const [breathText, setBreathText] = useState('Start')

  useEffect(() => {
    let interval: NodeJS.Timeout

    if (isBreathing) {
      interval = setInterval(() => {
        setBreathText((prevText) => {
          if (prevText === 'Inhale') return 'Hold'
          if (prevText === 'Hold') return 'Exhale'
          return 'Inhale'
        })
      }, 4000) // Change every 4 seconds
    }

    return () => {
      if (interval) clearInterval(interval)
    }
  }, [isBreathing])

  const handleClick = () => {
    if (!isBreathing) {
      setIsBreathing(true)
      setBreathText('Inhale')
    } else {
      setIsBreathing(false)
      setBreathText('Start')
    }
  }

  return (
    <div className="text-center">
      <h2 className="text-2xl font-bold mb-4">Breathing Exercise</h2>
      <motion.div
        className="w-48 h-48 bg-blue-500 rounded-full mx-auto flex items-center justify-center cursor-pointer"
        animate={{
          scale: breathText === 'Inhale' ? 1.2 : breathText === 'Hold' ? 1.2 : 1,
        }}
        transition={{ duration: 4, ease: 'easeInOut' }}
        onClick={handleClick}
      >
        <span className="text-white text-2xl font-bold">{breathText}</span>
      </motion.div>
    </div>
  )
}

