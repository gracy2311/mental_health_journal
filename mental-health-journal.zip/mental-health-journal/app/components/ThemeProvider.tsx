'use client'

import { createContext, useContext, useState, useEffect } from 'react'
import { ThemeProvider as NextThemesProvider } from 'next-themes'
import { type ThemeProviderProps } from 'next-themes/dist/types'

type EmotionThemeContextType = {
  emotionColor: string;
  setEmotionColor: (color: string) => void;
}

const EmotionThemeContext = createContext<EmotionThemeContextType | undefined>(undefined)

export function ThemeProvider({ children, ...props }: ThemeProviderProps) {
  const [emotionColor, setEmotionColor] = useState('#FFFFFF')

  useEffect(() => {
    document.body.style.setProperty('--emotion-color', emotionColor)
  }, [emotionColor])

  return (
    <EmotionThemeContext.Provider value={{ emotionColor, setEmotionColor }}>
      <NextThemesProvider {...props}>
        {children}
      </NextThemesProvider>
    </EmotionThemeContext.Provider>
  )
}

export function useEmotionTheme() {
  const context = useContext(EmotionThemeContext)
  if (context === undefined) {
    throw new Error('useEmotionTheme must be used within a ThemeProvider')
  }
  return context
}

