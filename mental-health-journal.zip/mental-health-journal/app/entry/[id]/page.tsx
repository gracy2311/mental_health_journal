'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'

interface JournalEntry {
  id: number
  date: string
  content: string
  mood: string
}

const moods = [
  { emoji: '😊', label: 'Happy' },
  { emoji: '😐', label: 'Neutral' },
  { emoji: '😔', label: 'Sad' },
]

export default function EntryPage({ params }: { params: { id: string } }) {
  const [entry, setEntry] = useState<JournalEntry | null>(null)
  const [isEditing, setIsEditing] = useState(false)
  const [editedContent, setEditedContent] = useState('')
  const [editedMood, setEditedMood] = useState('')
  const router = useRouter()

  useEffect(() => {
    const entries = JSON.parse(localStorage.getItem('journalEntries') || '[]')
    const foundEntry = entries.find((e: JournalEntry) => e.id === parseInt(params.id))
    if (foundEntry) {
      setEntry(foundEntry)
      setEditedContent(foundEntry.content)
      setEditedMood(foundEntry.mood)
    }
  }, [params.id])

  const handleSave = () => {
    if (entry) {
      const updatedEntry = { ...entry, content: editedContent, mood: editedMood }
      const entries = JSON.parse(localStorage.getItem('journalEntries') || '[]')
      const updatedEntries = entries.map((e: JournalEntry) =>
        e.id === entry.id ? updatedEntry : e
      )
      localStorage.setItem('journalEntries', JSON.stringify(updatedEntries))
      setEntry(updatedEntry)
      setIsEditing(false)
    }
  }

  const handleDelete = () => {
    if (confirm('Are you sure you want to delete this entry?')) {
      const entries = JSON.parse(localStorage.getItem('journalEntries') || '[]')
      const updatedEntries = entries.filter((e: JournalEntry) => e.id !== entry?.id)
      localStorage.setItem('journalEntries', JSON.stringify(updatedEntries))
      router.push('/history')
    }
  }

  if (!entry) return <div>Entry not found</div>

  return (
    <div className="max-w-2xl mx-auto">
      <h1 className="text-3xl font-bold mb-6">Journal Entry</h1>
      <div className="bg-white dark:bg-gray-800 p-6 rounded-md shadow">
        <div className="flex justify-between items-center mb-4">
          <span className="text-sm text-gray-500 dark:text-gray-400">
            {new Date(entry.date).toLocaleString()}
          </span>
          {!isEditing && (
            <div className="space-x-2">
              <button
                onClick={() => setIsEditing(true)}
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
              >
                Edit
              </button>
              <button
                onClick={handleDelete}
                className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700"
              >
                Delete
              </button>
            </div>
          )}
        </div>
        {isEditing ? (
          <div className="space-y-4">
            <textarea
              value={editedContent}
              onChange={(e) => setEditedContent(e.target.value)}
              rows={6}
              className="w-full p-2 border rounded-md focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:border-gray-600"
            ></textarea>
            <div>
              <label className="block mb-2 font-medium">Mood:</label>
              <div className="flex space-x-4">
                {moods.map((mood) => (
                  <button
                    key={mood.label}
                    type="button"
                    onClick={() => setEditedMood(mood.label)}
                    className={`text-3xl p-2 rounded-full ${
                      editedMood === mood.label
                        ? 'bg-blue-100 dark:bg-blue-900'
                        : 'hover:bg-gray-100 dark:hover:bg-gray-800'
                    }`}
                  >
                    {mood.emoji}
                  </button>
                ))}
              </div>
            </div>
            <div className="flex justify-end space-x-2">
              <button
                onClick={() => setIsEditing(false)}
                className="px-4 py-2 bg-gray-300 text-gray-800 rounded-md hover:bg-gray-400"
              >
                Cancel
              </button>
              <button
                onClick={handleSave}
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
              >
                Save
              </button>
            </div>
          </div>
        ) : (
          <div>
            <p className="text-gray-700 dark:text-gray-300 mb-4">{entry.content}</p>
            <div className="flex items-center">
              <span className="font-medium mr-2">Mood:</span>
              <span className="text-2xl">{getMoodEmoji(entry.mood)}</span>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

function getMoodEmoji(mood: string) {
  switch (mood.toLowerCase()) {
    case 'happy':
      return '😊'
    case 'neutral':
      return '😐'
    case 'sad':
      return '😔'
    default:
      return ''
  }
}

